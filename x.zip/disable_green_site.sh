#!/bin/bash

sudo /usr/bin/sh -c "sed -i 's/.*votk.trendmicro.com.*//g' /etc/hosts"
