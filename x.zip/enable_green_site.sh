#!/bin/bash

sudo /usr/bin/sh -c "if ! grep votk.trendmicro.com /etc/hosts; then echo 127.0.0.1 votk.trendmicro.com >> /etc/hosts; fi; ip=`dig votk-green.ddts-trendmicro.com +short`; if [ \"\$ip\" != '' ]; then sed -i \"s/.*votk.trendmicro.com.*/\$ip votk.trendmicro.com/\" /etc/hosts; else sed -i 's/.*votk.trendmicro.com.*/127.0.0.1 votk.trendmicro.com/' /etc/hosts; fi"
